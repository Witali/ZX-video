"""Experimental host-side soft contours from source RGB, before dithering.

This detects strong image edges, not semantic object boundaries. Blur and
short-component rejection limit texture noise. The Z80 format is unchanged.
"""
import cv2
import numpy as np

import five_level_dither as five
import monochrome_five_level as mono

PARAMETERS = dict(blur_kernel=5, blur_sigma=.9, canny_low=60, canny_high=120,
                  minimum_component_pixels=6, shade_steps=1)


def edge_mask(image):
    mono.luma_numerator(image)  # Shared shape/dtype validation.
    active = np.ascontiguousarray(image[12:84])
    smooth = cv2.GaussianBlur(active, (5,5), .9, borderType=cv2.BORDER_REPLICATE)
    # Multichannel gradients retain colour boundaries with similar luma.
    edges = cv2.Canny(smooth, 60, 120, L2gradient=True)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(edges, connectivity=8)
    keep = np.zeros(count, dtype=bool)
    keep[1:] = stats[1:,cv2.CC_STAT_AREA] >= 6
    result = np.zeros((96,128), dtype=bool)
    result[12:84] = keep[labels]
    return result


def encode(image):
    original = mono.encode(image)
    levels = five.unpack_levels(original[:3840])
    mask = edge_mask(image)
    # A soft line lowers coverage by only one step, without changing phase
    # or erasing the interior of the object. Zero already represents black.
    selected = mask & (levels > 0)
    levels[selected] -= 1
    return five.pack_levels(levels)+original[3840:], mask
