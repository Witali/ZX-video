"""Install the experimental queue into a current independently booted player.

Returns debugger patches plus fresh measurement labels. Images/packets are
unchanged. Bootstrap's old ring preload is discarded and measured playback
rereads the full video stream. This is an integration fixture, not a release
builder, capacity check or bootstrap optimization.
"""
from copy import deepcopy
from build_fap3_trd import player_harness,sha
from bulk_frame_stream import read_packet
from probe_motion_entropy import Reader
from probe_spatial_contexts import read_header
import bank_local_zx0 as local
import direct_slot_input_z80 as producer
import slot_queue_z80 as queue
import fap3_disk_z80 as disk
import pipelined_frame_z80 as video
import bulk_frame_z80 as packet


def build(metadata,raw,*,uncontended=False,compiled_masks=False,idle_masks=False,partial_consumption=False,cached_huffman_byte=False,inline_literals=False,demand_decode=False,hl_mask_reader=False):
    if hl_mask_reader and (not compiled_masks or idle_masks):
        raise ValueError('HL mask reader requires compiled masks without idle overrides')
    if idle_masks and not compiled_masks:
        raise ValueError('idle stripes require compiled metadata')
    if idle_masks and uncontended:
        raise ValueError('idle-mask relocation is not verified')
    cached_in_bootstrap=bool(metadata.get('cached_huffman_byte',False))
    cached_huffman_byte=cached_huffman_byte or cached_in_bootstrap
    if uncontended and cached_huffman_byte and not cached_in_bootstrap:
        raise ValueError('relocated cached-byte fixture requires a cached-Huffman bootstrap')
    if cached_huffman_byte and idle_masks:
        raise ValueError('cached-byte combination with idle stripes is not verified')
    m=deepcopy(metadata)
    if not m.get('irq_safe_paging') or not m.get('independently_bootable'):
        raise ValueError('queue requires IRQ-safe paging and an independent volume')
    if sha(raw)!=m['raw_sha256']:raise ValueError('wrong volume Huffman stream')
    r=Reader(raw);_,_,count,mapping,tables=read_header(r,magic=b'FAP3')
    ay=bytearray(11)
    for _ in range(m['frame_start']):
        _,detail=read_packet(r,stored_guards=False)
        for tick in detail['ticks']:
            for i in range(tick[0]):ay[tick[1+2*i]]=tick[2+2*i]
    options={key:m[key] for key in ('inline_matches','fast_noop_scan','irq_safe_paging',
        'static_cache_borders','carry_huffman','register_fragments')}
    options['cached_huffman_byte']=cached_in_bootstrap
    h=player_harness(bytes(4),tables,mapping,m['frames'],**options)
    zcode,z=local.build(dynamic_input=True,inline_literals=inline_literals)
    if inline_literals:
        m['inline_literals']=dict(code_sha256=sha(zcode),code_bytes=len(zcode),labels=z,
            zx0_only=True,literal_delta_tstates=-27,block_begin_delta_tstates=-17,
            compressed_stream_delta_bytes=0,code_growth_bytes=-16)
    dcode,d,drows=disk.build_disk(m['video_start_sector'],m['video_sectors'],
        fast_disk=True,cached_seek=True,interleaved=True)
    scode,seek,srows=disk.build_cached_seek(d)
    pcode,p,prows=producer.build(z,d)
    partial_consumption=partial_consumption or demand_decode
    regions,q,qrows=queue.build(z,p,len(m['blocks']),partial_consumption=partial_consumption,demand_decode=demand_decode)
    if demand_decode:
        m['demand_decode']=dict(helper_start=queue.DEMAND,helper_end=q['demand_end'],
            queue_bytes=q['end']-queue.CODE,helper_bytes=q['demand_end']-queue.DEMAND,
            extra_variable_bytes=0,extra_stream_bytes=0,background_quantum=256)
    mask_labels=h.frame.metadata_labels
    prefill=q['prefill']
    mask_rows=[]
    if compiled_masks:
        import compiled_masks_z80 as masks
        mask_regions,mask_labels,mask_rows,generated=masks.build(prefill_entry=prefill,hl_flags=hl_mask_reader)
        if q['end']>masks.INIT:raise ValueError('queue overlaps mask generator')
        regions+=mask_regions
        prefill=mask_labels['initialize']
        m['compiled_masks']=dict(labels=mask_labels,
            stored_bytes=sum(len(b) for _,b in mask_regions),
            generated_regions=[dict(address=a,bytes=len(b),sha256=sha(b)) for a,b in generated],
            initialize_cpu_tstates=201509,initialization_before_playback=True,
            baseline_partial_group='370+8*popcount',partial_group=f'{268 if hl_mask_reader else 276}+5*popcount-2*LSB',
            zero_group_tstates=masks.group_tstates(0,hl_flags=hl_mask_reader),
            full_group_tstates=masks.group_tstates(255,hl_flags=hl_mask_reader),decode_overhead_tstates=203 if hl_mask_reader else 158)
        if hl_mask_reader:
            m['hl_mask_reader']=dict(enabled=True,flags_cursor='alternate HL via EXX',preserves_alternate_registers=True,
                group_read_tstates_before=29,group_read_tstates=21,groups_per_frame=68,
                setup_and_restore_delta_tstates=45,frame_delta_tstates=-499,extra_stack_bytes=2,
                code_growth_bytes=7,extra_stream_bytes=0,extra_buffer_bytes=0,
                timing_source='https://www.zilog.com/docs/z80/um0080.pdf')
    if idle_masks or (cached_huffman_byte and not cached_in_bootstrap):
        from benchmark_static_cache_borders import OPTIONS
        from frame_output_pipeline import Harness
        import causal_tile_z80 as reconstruction
        import attribute_groups_z80 as groups
        import idle_masks_z80 as idle
        f=Harness(tables,mapping,metadata_mode='idle' if idle_masks else 'standard',deferred_publish=True,dynamic_source=True,
            dynamic_metadata=True,split_prepare=True,page_entry=video.PAGE,preloaded_mask='idle' if idle_masks else True,
            static_cache_borders=m['static_cache_borders'],carry_huffman=m['carry_huffman'],
            register_fragments=m['register_fragments'],cached_huffman_byte=cached_huffman_byte,**OPTIONS)
        if f.w!=h.frame.w or f.draw_code!=h.frame.draw_code:
            raise ValueError('reconstruction fixture changed the wrapper ABI or native renderer')
        # Reassemble all references to reconstruction state, including attribute
        # helpers. Bank-6 lookup tables are unchanged; install fixed RAM only.
        fixed=[(reconstruction.CODE,f.recon_code),(f.w['run'],f.wrapper_code),(groups.CODE,f.group_code)]
        fixed += [(a,b) for a,b in f.protected_regions if a<0xc000]
        changes={a+i:v for a,b in fixed for i,v in enumerate(b) if h.cpu.read8(a+i)!=v}
        for address in sorted(changes): regions.append((address,bytes([changes[address]])))
        if idle_masks:
            mask_code,mask_labels,idle_rows=idle.build(vector_pointer=f.w['vector_pointer'])
            regions.append((idle.CODE,mask_code));mask_rows+=idle_rows
        # These rows document the changed fixed CPU path; metadata generation
        # rows are already present in mask_rows.
        mask_rows += [row for row in f.instructions.values() if row['phase'] in ('reconstruct','handoff','attribute_groups')]
        if idle_masks:
            m['idle_masks']=dict(labels=mask_labels,reconstruction_labels=f.recon,
                code_sha256=sha(mask_code),code_bytes=len(mask_code),fixed_patch_bytes=len(changes),
                flags_start=idle.IDLE_BASE+1,flags_bytes=12,vector_pointer=f.w['vector_pointer'],
                extra_packet_bytes=0,poisoned_masks_cpu_test_required=True)
        else:
            m['cached_huffman_byte']=dict(reconstruction_labels=f.recon,
                code_sha256=sha(f.recon_code),code_bytes=len(f.recon_code),fixed_patch_bytes=len(changes),
                code_growth_bytes=len(f.recon_code)-len(h.frame.recon_code),extra_packet_bytes=0,
                extra_tables_bytes=0,initialization_tstates=19,
                short_inside_delta_tstates=-15,short_cross_delta_tstates=4,long_delta_tstates=4)
    if cached_in_bootstrap:
        # The real bootstrap already restores all changed reconstruction
        # references. Do not patch thousands of relocated bytes a second time.
        f=h.frame
        old_options=dict(options,cached_huffman_byte=False)
        old=player_harness(bytes(4),tables,mapping,m['frames'],**old_options)
        m['cached_huffman_byte']=dict(reconstruction_labels=f.recon,
            code_sha256=sha(f.recon_code),code_bytes=len(f.recon_code),fixed_patch_bytes=0,
            code_growth_bytes=len(f.recon_code)-len(old.frame.recon_code),
            extra_packet_bytes=0,extra_tables_bytes=0,initialization_tstates=19,
            short_inside_delta_tstates=-15,short_cross_delta_tstates=4,long_delta_tstates=4,
            in_bootstrap=True)
        mask_rows += [row for row in f.instructions.values() if row['phase'] in ('reconstruct','handoff','attribute_groups')]
    vregions,vl,vrows=video.build_video(h.frame.draw,z,h.audio,irq_safe_paging=True)
    regions += [(a,b) for a,b in vregions if a==video.VIDEO]
    code,bridge,pl,rows=packet.build(z,q,h.frame.w,h.frame.draw,mask_labels,h.audio,
        stored_guards=False,separate_prepare='idle',page_entry=video.PAGE)
    regions += [(packet.CODE,code),(packet.BRIDGE,bridge)]
    ccode,c,crows=video.build_clock(pl,h.audio,h.frames,zx0=z,progress_entry=h.progress['tick'],
        packet_ahead='idle',disk_idle_entry=q['step'])
    if c['end']>disk.DRIVER:raise ValueError('clock overlaps driver')
    drivercode,driver=disk.build_driver(h,c,bytes(ay),has_next=m['frame_end_exclusive']<count,
        prefill_entry=prefill)
    regions += [(local.CODE,zcode),(producer.CODE,pcode),(disk.DISK,dcode),
        (disk.CACHED_SEEK,scode),(video.CODE,ccode),(disk.DRIVER,drivercode)]
    # Original packet/bridge bytes are known; only patch their differences.
    # Other regions are installed in full, including all mutable state.
    sparse=[]
    for base,blob in regions:
        for i,value in enumerate(blob):
            address=base+i
            if base in (packet.CODE,packet.BRIDGE,video.VIDEO) and h.cpu.read8(address)==value:continue
            sparse.append((address,value))
    if uncontended:
        from uncontended_frame import patches as frame_patches,CHECKPOINT_COPIES
        # Read the final packet/clock/queue image, not the original reader.
        image={a+i:v for a,blob in regions for i,v in enumerate(blob)}
        def read8(address):return image.get(address,h.cpu.read8(address))
        current_rows={pc:row for pc,row in h.frame.instructions.items()}
        current_rows.update({row['address']:row for row in rows})
        # Include the final cached reconstruction and compiled runtime. The
        # generated mask bodies are not installed yet and contain no absolute
        # data operands; do not interpret the bank-6 bytes at their addresses.
        current_rows.update({row['address']:row for row in mask_rows
            if row['address']<0xc000 or compiled_masks and row['address']<masks.TABLE})
        extra,audit=frame_patches(read8,current_rows.values())
        sparse=sorted(dict(sparse+extra).items())
        m.update(uncontended_frame=audit,fixture_checkpoint_copies=CHECKPOINT_COPIES)
    lab=dict(m['player_labels']);lab.update(driver)
    for name in ('disk_full_call','disk_return','fast_read_enter','fast_disk_return','fast_read_retry','disk_finish'):
        lab[name]=d[name]
    lab.update({name:seek[name] for name in ('seek_side_enter','seek_side_return','seek_enter','seek_return')})
    lab['zx0_fatal']=z['fatal']
    lab['publish_out']=vl['publish_out']
    m.update(player_labels=lab,disk_labels=d,decoder_labels=z,seek_labels=seek,deferred_labels={},
        packet_labels=pl,clock_labels=c,queue_labels=q,producer_labels=p,
        native_ready_pcs=[row['address']+3 for row in crows if row['instruction'] in ('CALL native zero','CALL draw_compact')],
        runtime_video_preload_sectors=0,slot_queue_fixture=True,release=False,
        partial_slot_consumption=partial_consumption,
        slot_queue_patches=sparse,slot_queue_patch_sha256=sha(bytes(v for _,v in sparse)),
        slot_queue_regions=[dict(address=a,bytes=len(b),sha256=sha(b)) for a,b in regions],
        slot_queue_instruction_listing=qrows+prows+drows+srows+crows+vrows+mask_rows)
    return sparse,m
