"""Audit and preserve the completed IMA3 waveform experiment, not a new test."""
import gzip,hashlib,json,shutil,wave
from pathlib import Path
import numpy as np
from assess_snr import FILTER
from build_ima3_disk import compress
from verify_pcm import save

root=Path(__file__).resolve().parents[1]
work=root/'.tmp/ima3-waveform32-disk'
archive=root/'audiobook-beeper/experiments/ima-3bit-waveform'
def read(name):return json.loads((work/name).read_bytes())
meta=read('player.json');native=read('native.json');fuse=read('fuse.json')
pre=read('preload-native.json');cold=read('preload-fuse.json');quality=read('quality.json')
independent=read('independent-ima.json');recording=read('sound-128/report.json')
with wave.open(str(work/'source-preview.wav'),'rb') as w:
    assert (w.getnchannels(),w.getsampwidth(),w.getframerate(),w.getnframes())==(1,1,8000,186880)
    source=w.readframes(w.getnframes())
assert hashlib.sha256(source).hexdigest()=='ea3c0d945a0cc349747664c137c3725aee3fe8cf5e17b991ae3e24f51829a304'
packed=gzip.decompress((work/'soundtrack.ima.gz').read_bytes())
compressed=gzip.decompress((work/'soundtrack.ima3.gz').read_bytes())
assert len(packed)==93440 and len(compressed)==70080 and compress(packed)==compressed
assert pre['ima_sha256']==meta['packed_sha256']==hashlib.sha256(packed).hexdigest()
memory=meta['memory']
assert memory['total_ram_bytes']==131072 and memory['unused_audio_capacity_bytes']==0
assert sum(memory[k] for k in ('adpcm_bytes','shadow_screen_bytes','bank5_tables_and_workspace_bytes','bank2_resident_bytes'))==131072
for report in (native,fuse):
    assert report['complete'] and report['cycles_verified']==2
    assert report['every_pdm_bit_exact'] and report['every_predictor_and_index_exact']
    assert report['pcm16_samples_verified']==373760 and report['bits_verified']==5985253
assert native['memory_guards_passed'] and native['every_output_port_uncontended']
assert fuse['cold_boot'] and fuse['paging_latches_verified'] and fuse['runtime_disk_reads']==0
assert fuse['loading_message']['shown_before_table_and_payload_reads'] and fuse['loading_message']['hidden_before_playback']
for report in (pre,cold):
    assert report['complete'] and report['progress_load']==report['progress_unpack']==list(range(1,33))
assert pre['full_resident_ima_exact'] and pre['code_and_tables_unchanged'] and pre['group_tstates']==285
assert pre['ima_bytes_verified']==cold['bytes_verified']==93440 and cold['every_expanded_byte_exact'] and cold['cold_boot']
assert cold['maximum_decode_seconds']==60 and cold['preloader_to_player_ready_seconds']<=60
assert independent['every_sample_exact'] and independent['samples']==186880
assert quality['reference_rate_hz']==8000 and quality['speed_within_two_percent']
assert abs(quality['mean_speed_error_percent'])<=2 and quality['complete_trace_phase_deltas_tstates']==[0,0]
scores=[]
for name in ('voice-jitter.json','loop-2-voice-jitter.json'):
    q=read(name)
    assert q['source_samples']==186880 and q['uniform_reference_rate_hz']==8000 and q['filter']==FILTER
    scores.append(q['fixed_mean_clock_total_snr_db'])
assert scores==quality['two_loop_clock_aware_snr_db'] and min(scores)>=20
times=np.frombuffer(gzip.decompress((work/'output-times.u32.gz').read_bytes()),'<u4').astype(np.int64)
count=meta['outputs_per_cycle']
assert len(times)==2*count+1 and np.all(np.diff(times)>0)
assert np.array_equal(times[[count,2*count]]-times[[0,count]],[82891452,82891452])
disk=(work/'audiobook-preview.trd').read_bytes();diskhash=hashlib.sha256(disk).hexdigest()
assert diskhash==fuse['trd_sha256']==recording['source_trd_sha256']==read('report.json')['trd_sha256']
assert recording['recording_complete'] and recording['two_wraps_observed'] and recording['all_half_second_windows_have_signal']
assert recording['paging_latches_match'] and recording['secondary_paging_unchanged']
assert recording['startup_seconds']<=60 and recording['recorded_playback_seconds']>=46.72
assert native['cycle_tstates']==79122532 and meta['loop_idle_pad_tstates']==69
archive.mkdir(parents=True,exist_ok=False)
files=['player.json','audiobook-preview.trd','soundtrack.ima.gz','soundtrack.ima3.gz','source-preview.wav',
       'native.json','fuse.json','preload-native.json','preload-fuse.json','independent-ima.json','phase-probe.json',
       'compensated-pcm.wav','preload-debugger.txt','preload-trace.txt.gz','quality.json',
       'voice-jitter.json','loop-2-voice-jitter.json','clock-aware-output-preview.wav','uniform-clock-source-preview.wav',
       'output-times.u32.gz','calibration/calibration.json','sound-128/report.json',
       'sound-128/fuse-debugger.txt','sound-128/fuse-trace.txt.gz']
for name in files:
    target=archive/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/name,target)
shutil.copy2(work/'report.json',archive/'validation.json')
shutil.copytree(work/'assembly',archive/'assembly')
shutil.copytree(work/'producer-source',archive/'producer-source')
shutil.copy2(work/'sound-128/fuse-preview.wav',archive/'result-preview.wav')
shutil.copy2(root/'.tmp/ima3-alphabet-check.json',archive/'alphabet-check.json')
for name in ('verify_ima_alphabet.py',):
    data=(root/'audiobook-beeper'/name).read_bytes().replace(b'\r\n',b'\n')
    (archive/'producer-source'/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
(archive/'producer-source/archive_ima3_waveform.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
for variant,folder in (('selected-host','ima3-waveform32'),('unverified-wide-host','ima3-waveform128')):
    dest=archive/variant;dest.mkdir()
    for name in ('report.json','soundtrack.ima.gz'):
        shutil.copy2(root/'.tmp'/folder/name,dest/name)
large=[]
for path in (work/'calibration/phase-03/verification-work/fuse-trace.txt.gz',work/'sound-128/capture.fmf.gz'):
    large.append(dict(path=str(path.relative_to(root)).replace('\\','/'),bytes=path.stat().st_size,
                      sha256=hashlib.sha256(path.read_bytes()).hexdigest(),included_in_git=False))
audit=dict(complete=True,full_original_source=True,ima3_bytes=70080,resident_ima_bytes=93440,
    pcm16_audio_ratio=len(source)*2/len(compressed),all_native_and_cold_fuse_samples_verified=True,
    all_preload_bytes_and_progress_verified=True,full_128k_ram_accounted=True,independent_cold_boot=True,
    no_playback_disk_reads=True,original_8000hz_clock_without_fitted_gain_or_delay=True,
    two_loop_snr_db=scores,minimum_required_snr_db=20,speed_error_percent=quality['mean_speed_error_percent'],
    phase_deltas_tstates=[0,0],maximum_startup_seconds=60,normal_startup_seconds=recording['startup_seconds'],
    normal_sound_capture_complete=True,trd_sha256=diskhash,physical_hardware_tested=False)
save(archive/'completion-audit.json',audit)
save(archive/'report.json',dict(date='2026-10-03',complete=True,quality_gate_passed=True,
    scope='Same full control source, IMA3 transport, waveform-aware PC encoding, unchanged live PDM player',
    source_sha256=hashlib.sha256(source).hexdigest(),source_samples=len(source),audit=audit,
    quality=quality,preloader=cold,recording=recording,
    playback_tstates=dict(ordinary=423,ordinary_delta=0,page_extra=14,page_delta=0,bank_extra=140,bank_delta=0,
                         native_cycle=79122532,previous_native_cycle=79122530,cycle_delta=2,
                         reason='Silent phase pad69 T replaces67 T; ordinary playback instructions unchanged'),
    minimum_margin_db=min(scores)-20,large_local_evidence=large,
    wider_host_candidate='20.518986 dB on old timeline only; not executed as a new disk and not selected',
    limitations=['Input-specific emulator result; not a guarantee for other recordings',
                 '20.071 dB does not establish subjective transparency or physical hardware SNR']))
for f in archive.rglob('*'):
    if f.is_file() and f.suffix in ('.asm','.py','.json'):
        f.write_bytes(f.read_bytes().replace(b'\r\n',b'\n'))
hashes={str(f.relative_to(archive)).replace('\\','/'):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
        for f in sorted(archive.rglob('*')) if f.is_file()}
save(archive/'evidence-hashes.json',hashes)
target=root/'ZX-audiobook-IMA3-waveform-test.trd'
if target.exists():assert target.read_bytes()==disk
else:target.write_bytes(disk)
print(json.dumps(audit),flush=True)
