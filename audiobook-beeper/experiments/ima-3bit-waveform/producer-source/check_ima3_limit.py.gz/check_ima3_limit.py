"""Replay the saved complete cold trace to check the explicit limit guard."""
import contextlib,gzip,hashlib,io,json,shutil,subprocess
from pathlib import Path
from unittest.mock import patch
from verify_ima3_preload import cold
from verify_pcm import save

root=Path(__file__).resolve().parents[1]
source=root/'.tmp/ima3-waveform32-disk'
out=root/'.tmp/ima3-limit-replay';out.mkdir(exist_ok=False)
for name in ('player.json','soundtrack.ima.gz'):
    shutil.copy2(source/name,out/name)
trace=gzip.decompress((source/'preload-trace.txt.gz').read_bytes())
completed=subprocess.CompletedProcess([],77,trace,b'')
benchmark=root/'audiobook-beeper/experiments/ima-lpc-preload/raw128/report.json'
with patch('verify_ima3_preload.subprocess.run',return_value=completed),contextlib.redirect_stdout(io.StringIO()):
    accepted=cold(out,Path('C:/Program Files (x86)/Fuse/fuse.exe'),benchmark,60)
    try:
        cold(out,Path('C:/Program Files (x86)/Fuse/fuse.exe'),benchmark,10)
    except AssertionError as error:
        assert str(error)=='explicit preparation limit exceeded'
    else:
        raise AssertionError('10 seconds must fail despite expansion fitting')
assert accepted['expansion_seconds']<10<accepted['preloader_to_player_ready_seconds']<60
report=dict(complete=True,scope=__doc__,new_emulator_run=False,limit_60_accepted=True,
    limit_10_rejected_for_whole_preparation=True,all_saved_trace_bytes_and_progress_rechecked=True,
    source_trace_sha256=hashlib.sha256(trace).hexdigest(),
    current_verifier_sha256=hashlib.sha256((root/'audiobook-beeper/verify_ima3_preload.py').read_bytes()).hexdigest())
archive=root/'audiobook-beeper/experiments/ima-3bit-waveform'
save(archive/'limit-replay-check.json',report)
(archive/'producer-source/check_ima3_limit.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(archive/'producer-source/verify_ima3_preload-final-guard.py.gz').write_bytes(gzip.compress((root/'audiobook-beeper/verify_ima3_preload.py').read_bytes(),mtime=0))
hashes={str(f.relative_to(archive)).replace('\\','/'):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
        for f in sorted(archive.rglob('*')) if f.is_file() and f.name!='evidence-hashes.json'}
save(archive/'evidence-hashes.json',hashes)
print(json.dumps(report),flush=True)
