"""Resident 1-bit beeper player: 64 deterministic Z80 T-states per PDM bit."""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'toolkit'))
from build_zxv_trd import MiniAssembler, TrdFile, basic_line, spectrum_bitmap_offset
from build_streaming_trd import place_files, calculate_file_start

ORIGIN = 0x8000
CPU_CLOCK = 3546900
BIT_TSTATES = 64
BANKS = (0, 4, 6, 1, 3, 7)
BANK_BYTES = 16384


def screen(byte_count):
    from PIL import Image, ImageDraw, ImageFont
    im = Image.new('1',(256,192)); draw = ImageDraw.Draw(im); font = ImageFont.load_default(size=13)
    for y,text in ((24,'BEEPER AUDIOBOOK'),(53,'O. HENRY / PDM TEST'),(84,'1 BIT / PORT FE'),
                   (111,'55 kHz CPU / ULA MEASURED'),(139,f'{byte_count//1024} KiB / RESIDENT AUDIO'),
                   (168,'RESET TO REPLAY')):
        box=draw.textbbox((0,0),text,font=font)
        draw.text(((256-(box[2]-box[0]))//2,y),text,font=font,fill=1)
    data=bytearray(6144)
    for y in range(192):
        for x in range(256):
            if im.getpixel((x,y)): data[spectrum_bitmap_offset(x//8,y)] |= 128>>(x&7)
    return bytes(data)+bytes([0x47])*768


def player(sections):
    a=MiniAssembler(ORIGIN)
    output_labels=[]
    def ld16(op,value): a.emit(op); a.word(value)
    def page(bank):
        ld16(0x01,0x7ffd); a.emit(0x3e,0x10|bank,0xed,0x79)
    def pad(t):
        # Harmless instructions after AND/OR, which always clear carry.
        # RET C is deliberately never taken; tests check stack and all byte values.
        choices={4:(0x00,),5:(0xd8,),7:(0x3e,0),12:(0x18,0)}
        plan={0:[]}
        for n in range(1,t+1):
            for cost in choices:
                if n-cost in plan:
                    plan[n]=plan[n-cost]+[cost]; break
        if t not in plan: raise ValueError(f'cannot pad {t} T')
        for cost in plan[t]: a.emit(*choices[cost])
    def bit(name):
        # RLC D 8; SBC A,A 4; AND 16 7; OUT (FE),A 11 = 30 T.
        a.emit(0xcb,0x02,0x9f,0xe6,0x10)
        a.label(name); output_labels.append(name); a.emit(0xd3,0xfe)
    a.label('start')
    a.emit(0xf3); ld16(0x31,0xb800); a.emit(0xfd,0x21); a.word(0x5c3a); a.emit(0xed,0x56)
    a.emit(0xaf,0xd3,0xfe)
    ld16(0x21,0x9000); ld16(0x11,0x4000); ld16(0x01,6912); a.emit(0xed,0xb0,0xfb)
    for s in sections:
        page(s['bank']); ld16(0x11,(s['sector']//16)*256+s['sector']%16)
        a.abs16((0xed,0x53),'disk_position')
        ld16(0x21,s['address']); a.emit(0x06,s['sectors']); a.abs16(0xcd,'read_n')
    a.emit(0xf3)
    # AY remains silent throughout the beeper experiment, including dirty starts.
    for register in (8,9,10):
        ld16(0x01,0xfffd); a.emit(0x3e,register,0xed,0x79)
        ld16(0x01,0xbffd); a.emit(0xaf,0xed,0x79)
    page(sections[0]['bank'])
    # Start after a normal ROM interrupt; mask interrupts throughout PDM output.
    a.emit(0xfb,0x76,0xf3)
    a.label('ready')
    ld16(0x01,0x7ffd); ld16(0x21,sections[0]['address']); a.emit(0x56)
    a.label('playback')
    for i,s in enumerate(sections):
        a.label(f'loop_{i}')
        for j in range(1,5): bit(f'out_{i}_{j}'); pad(34)
        bit(f'out_{i}_5')
        # 6 + 4 + 4 + 10 = 24 T. Detect page end while three bits remain in D.
        a.emit(0x23,0x7c,0xb5); a.abs16(0xca,f'boundary_{i}'); pad(10)
        bit(f'out_{i}_6'); pad(34)
        bit(f'out_{i}_7'); a.emit(0x5e); pad(27) # Next byte, 7+27 T.
        bit(f'out_{i}_8'); a.emit(0x53); pad(20); a.abs16(0xc3,f'loop_{i}') # 4+20+10 T.
        a.label(f'boundary_{i}'); pad(10)
        bit(f'out_{i}_tail6')
        if i+1<len(sections):
            next_section=sections[i+1]
            a.emit(0x3e,0x10|next_section['bank'])
            a.label(f'page_{i}'); a.emit(0xed,0x79)
            ld16(0x21,next_section['address']); pad(5) # 7+12+10+5 T.
            bit(f'out_{i}_tail7'); a.emit(0x5e); pad(27)
            bit(f'out_{i}_tail8'); a.emit(0x53); pad(20); a.abs16(0xc3,f'loop_{i+1}')
        else:
            pad(34); bit(f'out_{i}_tail7'); pad(34); bit(f'out_{i}_tail8')
            pad(49); a.emit(0xaf) # 49+4+11 = one final 64-T hold.
            a.label('mute'); a.emit(0xd3,0xfe)
            a.label('finished'); a.emit(0x76); a.rel8(0x18,'finished')
    a.label('read_n')
    a.emit(0xc5,0xe5); a.abs16((0xed,0x5b),'disk_position'); ld16(0x01,0x0105)
    a.label('disk_call'); ld16(0xcd,0x3d13)
    a.emit(0xe1,0xc1,0x24); a.abs16((0xed,0x5b),'disk_position')
    a.emit(0x1c,0xcb,0x63); a.rel8(0x28,'sector_ok'); a.emit(0x1e,0,0x14)
    a.label('sector_ok'); a.abs16((0xed,0x53),'disk_position'); a.rel8(0x10,'read_n'); a.emit(0xc9)
    a.label('disk_position'); a.word(0)
    code=a.resolve()
    if len(code)>4096: raise ValueError('player overlaps screen staging buffer')
    return code+bytes(4096-len(code))+screen(sum(s['bytes'] for s in sections)),a.labels,output_labels


def build_disk(packed):
    if not packed or len(packed)%256 or len(packed)>len(BANKS)*BANK_BYTES:
        raise ValueError('PDM must contain 1..384 complete 256-byte sectors')
    sections=[]
    for i in range(0,len(packed),BANK_BYTES):
        size=min(BANK_BYTES,len(packed)-i)
        sections.append(dict(bank=BANKS[i//BANK_BYTES],sector=0,sectors=size//256,
                             bytes=size,address=0x10000-size))
    basic=b''.join([basic_line(10,b'\xfd \xb0 "32767"'),
        basic_line(20,b'\xf9 \xc0 \xb0 "15619":\xea:\xef "PLAYER" \xaf'),
        basic_line(30,b'\xf9 \xc0 \xb0 "32768"')])
    boot=TrdFile('boot','B',basic,autostart_line=10)
    draft,_,_=player(sections)
    track,sector=calculate_file_start([boot,TrdFile('PLAYER','C',draft,start=ORIGIN)])
    position=track*16+sector
    for s in sections: s['sector']=position; position+=s['sectors']
    code,labels,outputs=player(sections)
    files=[boot,TrdFile('PLAYER','C',code,start=ORIGIN)]
    for i,s in enumerate(sections):
        files.append(TrdFile(f'PDM{i}','C',packed[i*BANK_BYTES:i*BANK_BYTES+s['bytes']],start=s['address']))
    disk,directory,capacity=place_files(files,'PDMBOOK')
    return disk,dict(origin=ORIGIN,bits=len(packed)*8,packed_bytes=len(packed),sections=sections,
        player_labels=labels,output_labels=outputs,directory=directory,capacity=capacity,
        packed_sha256=hashlib.sha256(packed).hexdigest(),cpu_clock_hz=CPU_CLOCK,
        deterministic_bit_tstates=64,deterministic_byte_tstates=512,
        nominal_bit_rate_hz=CPU_CLOCK/64,nominal_duration_seconds=len(packed)*8*64/CPU_CLOCK,
        timing=dict(output_kernel=30,padding_and_housekeeping=34,boundary_test=24,
                    page_change=29,final_hold=64,irq_during_playback=False,
                    excludes='ULA memory and I/O contention; measured separately in Fuse'),
        memory=dict(bank_2='8000..8FFF code, 9000..AAFF screen staging, B800 stack',
                    bank_5='screen, BASIC and TR-DOS workspace',payload_banks=list(BANKS),
                    maximum_payload_bytes=98304,runtime_disk_reads=0))
