from pathlib import Path
import json,subprocess,time,os
root=Path('C:/Work/ZX-video')
work=root/'.tmp/live-pdm-stop-diagnosis';work.mkdir(parents=True,exist_ok=True)
meta=json.loads((root/'audiobook-beeper/pcm-live-preview/player.json').read_bytes());labels=meta['player_labels']
lines=['base 10','set $wraps 0'];i=0

def event(address,tag,expr,after=(),condition='',stop=False):
    global i
    i+=1;lines.extend([f'breakpoint {address}',f'commands {i}',f'print {tag}'])
    lines.extend('print '+s for s in expr);lines.extend(after);lines.extend(['exit 77' if stop else 'continue','end'])
    if condition:lines.append(f'condition {i} {condition}')
event(labels['ready'],100,['spectrum:frames','ula:tstates'])
for n in range(6):
    event(labels[f'page_{n}']+2,150,['spectrum:frames','ula:tstates','z80:a','z80:d','ula:mem7ffd','ula:mem1ffd'],['set $wraps $wraps+1'] if n==5 else [])
event(labels['out_0_0_0']+4,200,['spectrum:frames','ula:tstates'],condition='$wraps==2',stop=True)
script='\n'.join(lines);(work/'paging-debugger.txt').write_text(script,encoding='utf-8',newline='\n')
fuse=Path('C:/Program Files (x86)/Fuse/fuse.exe')
command=[str(fuse),'--no-sound','--no-autosave-settings','--no-confirm-actions','--speed','10000','--debugger-command',script,str(root/'ZX-audiobook-PDM-live-test.trd')]
startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
start=time.time()
result=subprocess.run(command,cwd=fuse.parent,capture_output=True,startupinfo=startup,timeout=80)
(work/'paging-default-stdout.txt').write_bytes(result.stdout);(work/'paging-default-stderr.txt').write_bytes(result.stderr)
print(json.dumps(dict(returncode=result.returncode,elapsed=time.time()-start,stdout=result.stdout.decode(errors='replace')[-7000:],stderr=result.stderr.decode(errors='replace')[-1500:],movie_bytes=(work/'paging-default.fmf').stat().st_size if (work/'paging-default.fmf').exists() else None)))
