from pathlib import Path
import struct,wave,json
from collections import Counter
p=Path('.tmp/live-pdm-stop-diagnosis/sound-default.fmf');b=p.read_bytes(); pos=16;audio=bytearray();counts=Counter();blocks=[];frame=0

def rle(n):
    global pos
    count=0
    while count<n:
        a=b[pos];pos+=1;count+=1
        if count<n and b[pos]==a:
            pos+=1;extra=b[pos];pos+=1;count+=1+extra
    assert count==n,(count,n,pos)
while pos<len(b):
    tag=chr(b[pos]);counts[tag]+=1
    if tag=='$':
        w=b[pos+4];h=int.from_bytes(b[pos+5:pos+7],'little');pos+=7
        rle(w*h);rle(w*h)
    elif tag=='N': counts['timing_'+chr(b[pos+3])]+=1;frame+=b[pos+1];pos+=4
    elif tag=='S':
        enc=chr(b[pos+1]);rate=int.from_bytes(b[pos+2:pos+4],'little');channels=1 if b[pos+4]==77 else 2
        n=int.from_bytes(b[pos+5:pos+7],'little')+1;pos+=7
        assert enc=='P' and rate==44100 and channels==1,(enc,rate,channels)
        blocks.append((frame,len(audio)//2,n));audio+=b[pos:pos+n*2];pos+=n*2
    elif tag=='X': pos+=1
    else: raise ValueError((tag,pos,b[pos:pos+30]))
with wave.open(str(p.with_suffix('.wav')),'wb') as w:
    w.setnchannels(1);w.setsampwidth(2);w.setframerate(44100);w.writeframes(audio)
print(json.dumps(dict(bytes=len(b),blocks=counts,frames=frame,samples=len(audio)//2,audio_seconds=len(audio)/88200,last_blocks=blocks[-4:])))
Path('.tmp/live-pdm-stop-diagnosis/fmf-default-audio-index.json').write_text(json.dumps(blocks))
