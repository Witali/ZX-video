"""RC-aware PDM generation on the host; independent of the release ASM.

Predict exact capacitor charge/discharge for each port hold. Integrate the
voltage error as well: greedy endpoint tracking alone need not preserve DC.
The reference voltage is the same RC applied to the intended PCM levels.
Actual saved Fuse hold times are reused as an offline scheduling assumption;
they are not a timing result for this new, as yet unported, modulator.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
import subprocess

import numpy as np

from apply_rc_filter import inspect
from build_pdm import write_wav
from ima_player import CPU_CLOCK
from verify_ima import reference

HERE = Path(__file__).resolve().parent
WAV_RATE = 44100


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rc_coefficients(holds, tau):
    a = np.exp(-holds / tau)
    c = -tau * np.expm1(-holds / tau)
    return a, c, holds - c


def modulate(target, holds, tau):
    """Choose the bit minimizing integrated RC voltage error at next edge.

    w = desired capacitor voltage - actual capacitor voltage.
    e = integral of w over time. Both capacitor models start at zero.
    For constant x/bit over h: w' = a*w + (1-a)*(x-bit),
    e' = e + c*w + (h-c)*(x-bit), c=tau*(1-a).
    Compare e' for bit=0 and bit=1; update both states with the chosen bit.
    The first three low bits preserve the current player's pipeline priming.
    """
    a, c, k = rc_coefficients(holds, tau)
    bits = np.empty(len(target), dtype=np.uint8)
    w = e = peak_w = peak_e = 0.0
    for i, (x, aa, cc, kk) in enumerate(zip(target, a, c, k)):
        unquantized = e + cc * w + kk * x
        bit = int(unquantized >= kk / 2) if i >= 3 else 0
        e = unquantized - kk * bit
        w = aa * w + (1 - aa) * (x - bit)
        peak_w, peak_e = max(peak_w, abs(w)), max(peak_e, abs(e))
        bits[i] = bit
    if not np.isfinite(e + w) or peak_w > 1 + 1e-12:
        raise AssertionError('RC/error state invalid')
    return bits, dict(peak_voltage_error=peak_w, peak_integral_error_seconds=peak_e,
                      final_voltage_error=w, final_integral_error_seconds=e)


def capacitor_states(levels, holds, tau):
    """Exact capacitor voltage at every hold boundary; zero initial voltage."""
    a, c, _ = rc_coefficients(holds, tau)
    states = np.empty(len(levels) + 1, dtype=np.float64)
    states[0] = 0
    for i, (x, aa) in enumerate(zip(levels, a)):
        states[i + 1] = x + (states[i] - x) * aa
    areas = np.r_[0., np.cumsum(levels * holds + (states[:-1] - levels) * c)]
    return states, areas


def render_rc(levels, times, tau, rate, states=None, areas=None):
    """Analytically integrate capacitor voltage into uniform PCM bins.

    No approximation of pulse widths on a uniform grid precedes the RC model.
    Only the final waveform export is sampled; an antialias resampler follows.
    """
    holds = np.diff(times)
    if states is None:
        states, areas = capacitor_states(levels, holds, tau)
    count = int(np.floor(times[-1] * rate))
    result = np.empty(count, dtype=np.float32)
    for start in range(0, count, 500000):
        end = min(start + 500000, count)
        edges = np.arange(start, end + 1, dtype=np.float64) / rate
        indices = np.clip(np.searchsorted(times, edges, side='right') - 1, 0, len(levels) - 1)
        elapsed = edges - times[indices]
        integrals = (areas[indices] + levels[indices] * elapsed
                     - tau * (states[indices] - levels[indices]) * np.expm1(-elapsed / tau))
        # Unipolar physical voltage 0..1 becomes bipolar audio around 0.5.
        result[start:end] = 2 * np.diff(integrals) * rate - 1
    return result


def resample(signal, rate, ffmpeg):
    command = [ffmpeg, '-v', 'error', '-nostdin', '-f', 'f32le', '-ar', str(rate),
               '-ac', '1', '-i', '-', '-af',
               f'aresample={WAV_RATE}:resampler=soxr:precision=28', '-f', 'f32le', '-']
    result = subprocess.run(command, input=signal.astype('<f4', copy=False).tobytes(),
                            capture_output=True, check=True)
    return np.frombuffer(result.stdout, '<f4').astype(float)


def speech_band(signal, ffmpeg):
    result = subprocess.run([ffmpeg, '-v', 'error', '-nostdin', '-f', 'f32le',
                            '-ar', str(WAV_RATE), '-ac', '1', '-i', '-', '-af',
                            'highpass=f=70,lowpass=f=4500:p=2,lowpass=f=4500:p=2',
                            '-f', 'f32le', '-'], input=signal.astype('<f4').tobytes(),
                            capture_output=True, check=True)
    return np.frombuffer(result.stdout, '<f4').astype(float)


def metrics(wanted, actual):
    a, b = wanted[4410:-4410], actual[4410:-4410]
    error = b - a
    return dict(snr_db=float(10 * np.log10(np.mean(a * a) / np.mean(error * error))),
                error_rms=float(np.sqrt(np.mean(error * error))),
                correlation=float(np.corrcoef(a, b)[0, 1]),
                dc_error=float(np.mean(error)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ffmpeg', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cutoff', type=float, default=20000)
    parser.add_argument('--seconds', type=float, default=None)
    args = parser.parse_args()
    if not 0 < args.cutoff < WAV_RATE / 2:
        parser.error('cutoff must be below WAV Nyquist')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('use a new or empty output directory')
    args.output.mkdir(parents=True, exist_ok=True)
    source = HERE / 'ima-preview'
    archive = json.loads((source / 'report.json').read_bytes())
    for name in ('player.json', 'verification.json', 'soundtrack.ima.gz', 'output-times.u32.gz'):
        if sha((source / name).read_bytes()) != archive['artifacts'][name]['sha256']:
            raise AssertionError(f'baseline artifact changed: {name}')
    meta = json.loads((source / 'player.json').read_bytes())
    proof = json.loads((source / 'verification.json').read_bytes())
    disk = HERE.parent / 'ZX-audiobook-IMA-ADPCM-test.trd'
    if sha(disk.read_bytes()) != proof['fuse']['trd_sha256']:
        raise AssertionError('release disk changed')
    packed = gzip.decompress((source / 'soundtrack.ima.gz').read_bytes())
    _, _, levels, baseline_bits, count = reference(packed, meta)
    all_times = np.frombuffer(gzip.decompress((source / 'output-times.u32.gz').read_bytes()), '<u4')
    times = all_times[:count + 1].astype(np.float64) / CPU_CLOCK
    if args.seconds is not None:
        count = min(count, int(np.searchsorted(times, args.seconds)))
        times = times[:count + 1]
    if count < 10000 or times[0] != 0 or np.any(np.diff(times) <= 0):
        raise ValueError('invalid or too short timeline')
    baseline_bits = baseline_bits[:count]
    target = np.r_[np.zeros(3), levels[:count - 3].astype(float) / 256]
    holds = np.diff(times)
    tau = 1 / (2 * math.pi * args.cutoff)
    candidate_bits, generator = modulate(target, holds, tau)
    rate = WAV_RATE * 16
    signals, states_for_check = {}, {}
    for name, samples in (('reference', target), ('baseline', baseline_bits), ('rc-aware', candidate_bits)):
        states, areas = capacitor_states(samples, holds, tau)
        if states.min() < -1e-12 or states.max() > 1 + 1e-12:
            raise AssertionError('capacitor voltage left supply rails')
        print(f'Rendering {name}: {count} holds', flush=True)
        signals[name] = resample(render_rc(samples, times, tau, rate, states, areas), rate, args.ffmpeg)
        if name == 'rc-aware':
            states_for_check = dict(states=states, areas=areas)
    frames = min(map(len, signals.values()))
    if max(map(len, signals.values())) != frames:
        raise AssertionError('rendered lengths differ')
    peaks = {name: float(np.max(abs(signal))) for name, signal in signals.items()}
    print('Rendered peaks: ' + json.dumps(peaks), flush=True)
    # Common attenuation also allows for antialias-resampler overshoot.
    # No independent normalization and no speech filter in the listening WAVs.
    gain = min(.8, .9 / max(peaks.values()))
    for name in ('baseline', 'rc-aware'):
        signal = signals[name] * gain
        if np.max(abs(signal)) >= 1:
            raise AssertionError('listening export would clip')
        write_wav(args.output / f'{name}-rc-preview.wav', signal)
        blob = np.packbits(baseline_bits if name == 'baseline' else candidate_bits).tobytes()
        (args.output / f'{name}.pdm.gz').write_bytes(gzip.compress(blob, mtime=0))
    filtered = {name: speech_band(signal, args.ffmpeg) for name, signal in signals.items()}
    rows = {name: dict(wideband=metrics(signals['reference'], signals[name]),
                       speech_band=metrics(filtered['reference'], filtered[name]))
            for name in ('baseline', 'rc-aware')}
    # Separate physical model conservation check: accumulated voltage error
    # equals the difference of the two independently rendered area totals.
    target_state, target_area = capacitor_states(target, holds, tau)
    actual_error = float(target_area[-1] - states_for_check['areas'][-1])
    if abs(actual_error - generator['final_integral_error_seconds']) > 1e-8:
        raise AssertionError('independent integrated RC error mismatch')
    if abs(float(target_state[-1] - states_for_check['states'][-1])
           - generator['final_voltage_error']) > 1e-10:
        raise AssertionError('independent capacitor state mismatch')
    report = dict(date='2026-10-02',host_experiment_complete=True,release=False,z80_ported=False,
                  trd_sha256=sha(disk.read_bytes()),duration_seconds=float(times[-1]),
                  source_start_seconds=60,slots=count,pdm_rate_hz=count/float(times[-1]),
                  cutoff_hz=args.cutoff,resistance_ohms=1000,capacitance_farads=tau/1000,
                  tau_seconds=tau,initial_capacitor_voltage=0,internal_render_rate_hz=rate,
                  generator='RC capacitor model plus integral of voltage error; causal one-slot bit choice',
                  reference='same RC driven by delayed decoded PCM8; not unfiltered original AAC',
                  target_delay_slots=3,generator_state=generator,
                  differing_bits=int(np.count_nonzero(candidate_bits != baseline_bits)),
                  packed_bit_order='MSB first; ignore padding bits beyond slots',
                  common_listening_gain=gain,independent_normalization=False,
                  listening_filters='ideal 20 kHz RC and SOXR antialias resampling only',
                  analysis_filters='70 Hz highpass, two 2-pole 4.5 kHz lowpasses; metrics only',
                  excluded_edge_seconds=.1,metrics=rows,
                  independent_area_error_difference_seconds=actual_error-generator['final_integral_error_seconds'],
                  sources={name:sha((source/name).read_bytes()) for name in
                           ('player.json','verification.json','soundtrack.ima.gz','output-times.u32.gz')},
                  producer_sha256_lf=sha(Path(__file__).read_bytes().replace(b'\r\n',b'\n')),
                  model_reference='https://openstax.org/books/university-physics-volume-2/pages/10-5-rc-circuits',
                  limitations=['New bits generated on PC, not by Z80 or Fuse',
                               'Saved baseline timings assumed; no new cycle counts or TRD',
                               'Ideal unloaded RC, not a measured Spectrum speaker circuit'],
                  files={f.name: inspect(f) for f in args.output.glob('*.wav')})
    report['speech_band_snr_change_db'] = rows['rc-aware']['speech_band']['snr_db'] - rows['baseline']['speech_band']['snr_db']
    (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(metrics=rows,change_db=report['speech_band_snr_change_db'],generator=generator)),flush=True)


if __name__ == '__main__':
    main()
